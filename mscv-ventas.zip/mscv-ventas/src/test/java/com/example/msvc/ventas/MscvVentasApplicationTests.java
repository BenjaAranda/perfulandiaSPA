package com.example.msvc.ventas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MscvVentasApplicationTests {

	@Test
	void contextLoads() {
	}

}
