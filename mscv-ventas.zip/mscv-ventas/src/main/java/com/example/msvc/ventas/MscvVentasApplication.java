package com.example.msvc.ventas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MscvVentasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MscvVentasApplication.class, args);
	}

}
